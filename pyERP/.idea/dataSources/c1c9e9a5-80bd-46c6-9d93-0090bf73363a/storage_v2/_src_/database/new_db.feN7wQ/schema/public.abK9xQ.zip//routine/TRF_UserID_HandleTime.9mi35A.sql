create function "TRF_UserID_HandleTime"()
  returns trigger
language plpgsql
as $$
BEGIN
  IF NEW."UserID" IS NULL THEN
    NEW."UserID" := 1;
  END IF;
  IF NEW."HandleTime" IS NULL THEN
    NEW."HandleTime" := NOW();
  END IF;
  RETURN NEW;
END;
$$;

