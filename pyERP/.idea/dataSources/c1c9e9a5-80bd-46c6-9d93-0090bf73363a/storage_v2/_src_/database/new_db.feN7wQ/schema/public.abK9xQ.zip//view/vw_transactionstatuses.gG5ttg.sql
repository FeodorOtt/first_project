create view vw_transactionstatuses as
  SELECT (1)::smallint AS "ID",
    'проведена'::character varying(50) AS "Name"
UNION ALL
 SELECT (2)::smallint AS "ID",
    'сторнирована'::character varying(50) AS "Name"
UNION ALL
 SELECT (3)::smallint AS "ID",
    'отложена'::character varying(50) AS "Name";

