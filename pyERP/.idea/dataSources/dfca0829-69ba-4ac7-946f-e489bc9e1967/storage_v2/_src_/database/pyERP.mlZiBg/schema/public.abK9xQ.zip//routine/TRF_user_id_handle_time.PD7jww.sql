create function "TRF_user_id_handle_time"()
  returns trigger
language plpgsql
as $$
BEGIN
  IF NEW."user_id" IS NULL THEN
    NEW."user_id" := 1;
  END IF;
  IF NEW."handle_time" IS NULL THEN
    NEW."handle_time" := NOW();
  END IF;
  RETURN NEW;
END;
$$;

